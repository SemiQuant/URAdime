from setuptools import setup

setup(
    name="URAdime",
    version="0.2.0",
    packages=["URAdime"],
    install_requires=[
        "pysam",
        "pandas",
        "biopython",
        "python-Levenshtein",
        "tqdm",
        "numpy",
    ],
) 